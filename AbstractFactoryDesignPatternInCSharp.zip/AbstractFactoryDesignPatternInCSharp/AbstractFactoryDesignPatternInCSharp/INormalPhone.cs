﻿namespace AbstractFactoryDesignPatternInCSharp
{
    /// <summary>
    /// The 'AbstractProductB' interface
    /// </summary>
    interface INormalPhone
    {
        string GetModelDetails();
    }
}
